

<?php
require_once "include/header.php";
?>

<?php

//  database connection
require_once "../connection.php";
//$emp_id=$_SESSION['id_emp'];
$sql = "SELECT *,admin.name as admin_name,employee.name as employee_name,tasks.id as task_id FROM tasks JOIN employee ON tasks.employee_id=employee.id JOIN admin ON tasks.admin_id=admin.id ";
$result = mysqli_query($conn , $sql);
//var_dump($result);
$i = 1;
$you = "";


?>

<style>
    .tasks-table {
        border-collapse: collapse;
        width: 100%;
        margin-bottom: 1rem;
    }

    .tasks-table th,
    .tasks-table td {
        padding: 0.75rem;
        text-align: left;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .tasks-table th {
        font-weight: bold;
    }

    .tasks-table td.status {
        font-weight: bold;
        text-transform: uppercase;
    }

    .tasks-table td.todo {
        color: #ffc107;
    }

    .tasks-table td.in-progress {
        color: #17a2b8;
    }

    .tasks-table td.done {
        color: #28a745;
    }

    .tasks-table a {
        margin-right: 0.5rem;
    }

    .tasks-table a.edit-btn {
        color: #007bff;
    }

    .tasks-table a.delete-btn {
        color: #dc3545;
    }
    .add-task-button {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .add-task-button a {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
    }

</style>

<table class="tasks-table">
    <thead>
    <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Status</th>
        <th>Assigned To</th>
        <th>Assigned By</th>
        <th>Comment</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // Loop through the SQL query results and output each row as a table row
    while ($row = mysqli_fetch_assoc($result)) {
//        var_dump($row);
        // Extract the data from the current row
        $title = $row['title'];
        $description = $row['description'];
        $status = $row['status'];
        $assigned_to = $row['employee_name'];
        $assigned_by = $row['admin_name'];
        $comment = $row['comment'];
        $id = $row['task_id'];

        // Output the data as a table row
        echo '<tr>';
        echo '<td>' . $title . '</td>';
        echo '<td>' . $description . '</td>';
        echo '<td class="status ' . $status . '">' . $status . '</td>';
        echo '<td>' . $assigned_to . '</td>';
        echo '<td>' . $assigned_by . '</td>';
        echo '<td>' . $comment . '</td>';
        echo '<td>';
        echo '<a href="./edit-task.php?task_id=' . $id . '" class="edit-btn">Edit</a>';
//        echo '<a href="#" class="delete-btn">Delete</a>';
        echo '</td>';
        echo '</tr>';
    }
    ?>
    </tbody>



</table>
<div class="add-task-button">
    <a href="./add-task.php">Add New Task</a>
</div>


<?php
require_once "include/footer.php";
?>
