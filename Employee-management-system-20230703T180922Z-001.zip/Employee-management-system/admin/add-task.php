<?php
session_start();
$admin_email = $_SESSION['email'];
//echo $admin_id;
?>

<?php

// Database connection
require_once "../connection.php";



// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the input data from the form
    $title = $_POST['title'];
    $description = $_POST['description'];
    //$status = $_POST['status'];
    $employee_id = $_POST['assigned_to'];
//    $employee_id = $_POST['employee_id'];
    $sql_query = "SELECT * FROM admin WHERE email='$admin_email'  ";
    $result = mysqli_query($conn , $sql_query);
    $data = mysqli_fetch_assoc($result);
    $admin_id=$data["id"];
    // Insert the new task into the database
    $sql = "INSERT INTO tasks (title, description, employee_id, admin_id) 
            VALUES ('$title', '$description', '$employee_id', '$admin_id')";
    $result = mysqli_query($conn, $sql);

    // Redirect to the employee tasks page
    header('Location: manage-employee-tasks.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Task</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        /* Center the form vertically and horizontally */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px;
        }
        h1 {
            text-align: center;
        }
        form {
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 500px;
            display: flex;
            flex-direction: column;
        }

        h1 {
            text-align: center;
        }

        label {
            margin-top: 10px;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: none;
            margin-top: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #3e8e41;
        }

    </style>
</head>
<body>
<div class="container">
    <h1>Add New Task</h1>
<form action="add-task.php" method="post">
    <label for="title">Title:</label>
    <input type="text" name="title" required>
    <label for="description">Description:</label>
    <textarea name="description" required></textarea>

    <label for="assigned_to">Assigned To:</label>
    <select name="assigned_to" required>
        <?php
        // Retrieve the list of employees from the database
        $sql = "SELECT id, name FROM employee";
        $result = mysqli_query($conn, $sql);

        // Loop through the results and display each employee as an option
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
        }
        ?>
    </select>


    <input type="submit" name="submit" value="Add Task">
</form>
</div>
</body>
</html>
