<?php
// Database connection
require_once "../connection.php";

// Check if the task ID is provided in the URL
if (isset($_GET['task_id'])) {
    $task_id = $_GET['task_id'];

    // Query to select the task data
    $sql = "SELECT * FROM tasks JOIN employee ON tasks.employee_id=employee.id WHERE tasks.id=$task_id LIMIT 1";

    // Execute the query and get the task data
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // Extract the task data
    $title = $row['title'];
    $description = $row['description'];
    $status = $row['status'];
    $employee_id = $row['employee_id'];
    $assigned_to = $row['name'];
    $comment = $row['comment'];
}

// Update the task data in the database
if (isset($_POST['update_task'])) {
    $task_id = $_POST['task_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $employee_id = $_POST['employee_id'];
    $comment = $_POST['comment'];

    // Query to update the task data
    $sql = "UPDATE tasks SET title='$title', description='$description', status='$status', employee_id=$employee_id, comment='$comment' WHERE id=$task_id";

    // Execute the query and check if it was successful
    if (mysqli_query($conn, $sql)) {
        // Redirect to the tasks page
        header("Location: manage-employee-tasks.php");
        exit();
    } else {
        // Display an error message
        $error_message = "Error updating task: " . mysqli_error($conn);
    }
}elseif (isset($_POST['delete_task'])){
    $task_id = $_POST['task_id'];

    $sql = "DELETE FROM TASKS WHERE id=$task_id";

    // Execute the query and check if it was successful
    if (mysqli_query($conn, $sql)) {
        // Redirect to the tasks page
        header("Location: manage-employee-tasks.php");
        exit();
    } else {
        // Display an error message
        $error_message = "Error updating task: " . mysqli_error($conn);
    }
}
?>
<form class="edit-task-form" action="edit-task.php" method="post">
    <input type="hidden" name="task_id" value="<?php echo $task_id ?>">
    <table>
        <tr>
            <td><label>Title:</label></td>
            <td><input type="text" name="title" value="<?php echo $title ?>"></td>
        </tr>
        <tr>
            <td><label>Description:</label></td>
            <td><textarea name="description"><?php echo $description ?></textarea></td>
        </tr>
        <tr>
            <td><label>Status:</label></td>
            <td>
                <select name="status">
                    <option value="todo" <?php if ($status == 'todo') echo 'selected' ?>>To Do</option>
                    <option value="in_progress" <?php if ($status == 'in-progress') echo 'selected' ?>>In Progress</option>
                    <option value="done" <?php if ($status == 'done') echo 'selected' ?>>Done</option>
                </select>
            </td>
        </tr>
        <tr>
            <td><label>Assigned to:</label></td>
            <td><input type="text" name="assigned_to" value="<?php echo $assigned_to ?>"></td>
        </tr>
        <tr>
            <td><label>Comment:</label></td>
            <td><textarea name="comment"><?php echo $comment ?></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input hidden name="employee_id" value="<?php echo $employee_id?>">
                <button class="update-btn" type="submit" name="update_task">Update</button>
                <button class="delete-btn" type="submit" name="delete_task">Delete</button>
<!--                <a href="delete-task.php?id=--><?php //echo $task_id ?><!--" class="delete-btn">Delete</a>-->
            </td>
        </tr>
    </table>
</form>

<style>
    .edit-task-form {
        border: 2px solid #ccc;
        padding: 20px;
        margin-bottom: 20px;
    }
    .edit-task-form label {
        font-weight: bold;
    }
    .edit-task-form input[type=text], .edit-task-form textarea {
        width: 100%;
        padding: 5px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    .edit-task-form select {
        width: 100%;
        padding: 5px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    .edit-task-form .update-btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-right: 10px;
    }
    .edit-task-form .delete-btn {
        background-color: #f44336;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
    }
    .edit-task-form .delete-btn:hover {
        background-color: #e53935;
    }
</style>


