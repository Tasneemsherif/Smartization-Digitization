<?php
// Connect to the database
$conn = mysqli_connect("localhost", "username", "password", "database_name");

// Check for errors
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the employee ID from the session
$employee_id = $_SESSION['employee_id'];

// Check if a new task was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task_description'])) {
    $task_description = mysqli_real_escape_string($conn, $_POST['task_description']);

    // Insert the task into the database
    $sql = "INSERT INTO tasks (employee_id, task_description) VALUES ('$employee_id', '$task_description')";
    if (!mysqli_query($conn, $sql)) {
        echo "Error: " . mysqli_error($conn);
    }
}

// Build the SQL query to select the tasks for the employee
$sql = "SELECT * FROM tasks WHERE employee_id = $employee_id";

// Execute the query and get the results
$result = mysqli_query($conn, $sql);

// Check for errors
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Display the tasks for the employee
if (mysqli_num_rows($result) > 0) {
    echo "<h2>Tasks</h2>";
    echo "<ul>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>" . $row["task_description"] . "</li>";
    }
    echo "</ul>";
} else {
    echo "No tasks found.";
}

// Close the database connection
mysqli_close($conn);
?>
<h2>Add a new task</h2>
<form method="POST">
  <input type="text" name="task_description" placeholder="Enter a task description">
  <input type="submit" value="Add Task">
</form>
