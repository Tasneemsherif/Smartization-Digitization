

<?php
require_once "include/header.php";
?>
<?php
/*session_start();
if( empty($_SESSION["email_emp"]) ){
    header("Location: ./login.php");
}
*/?>
<?php

//  database connection
require_once "../connection.php";
$emp_id=$_SESSION['id_emp'];
$sql = "SELECT * FROM tasks JOIN employee ON tasks.employee_id=employee.id WHERE employee_id=$emp_id";
$result = mysqli_query($conn , $sql);
//var_dump($result);
$i = 1;
$you = "";


?>



<table class="tasks-table">
    <thead>
    <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Status</th>
        <th>Comment</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // Loop through the SQL query results and output each row as a table row
    while ($row = mysqli_fetch_assoc($result)) {
//        var_dump($row);
        // Extract the data from the current row
        $title = $row['title'];
        $description = $row['description'];
        $status = $row['status'];
        $commetn = $row['comment'];

        // Output the data as a table row
        echo '<tr>';
        echo '<td>' . $title . '</td>';
        echo '<td>' . $description . '</td>';
        echo '<td class="status ' . $status . '">' . $status . '</td>';
        echo '<td>' . $commetn . '</td>';
        echo '</tr>';
    }
    ?>
    </tbody>
</table>


<?php
require_once "include/footer.php";
?>

<?php
require_once "include/footer.php";
?>