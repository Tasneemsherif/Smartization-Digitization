<!DOCTYPE html>
<html>
<head>
  <title>Tasks System</title>
</head>
<body>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
  <h1>Tasks System</h1>
