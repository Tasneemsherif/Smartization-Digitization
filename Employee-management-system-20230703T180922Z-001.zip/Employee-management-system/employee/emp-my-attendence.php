


<?php
//Aziz
require_once "include/header.php";
//$emp_id=$_SESSION['id_emp'];
$emp_id=13;

?>


<?php

//  database connection
require_once "../connection.php";


$sql = "SELECT employees_attendence.id as att_id,  employee.email as employee_email,employees_attendence.attendance,employees_attendence.created_at FROM employees_attendence JOIN employee ON employees_attendence.employee_id=employee.id where employee.id=$emp_id";
$result = mysqli_query($conn , $sql);

$i = 1;

?>

<style>
    .tasks-table {
        border-collapse: collapse;
        width: 100%;
        margin-bottom: 1rem;
    }

    .tasks-table th,
    .tasks-table td {
        padding: 0.75rem;
        text-align: left;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .tasks-table th {
        font-weight: bold;
    }

    .tasks-table td.status {
        font-weight: bold;
        text-transform: uppercase;
    }

    .tasks-table td.todo {
        color: #ffc107;
    }

    .tasks-table td.absent {
        color: #ff0046;
    }

    .tasks-table td.attendee {
        color: #28a745;
    }

    .tasks-table a {
        margin-right: 0.5rem;
    }

    .tasks-table a.edit-btn {
        color: #007bff;
    }

    .tasks-table a.delete-btn {
        color: #dc3545;
    }
    .add-task-button {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .add-task-button a {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
    }

</style>

<table class="tasks-table">
    <thead>
    <tr>
        <th>Employee Email</th>
        <th>Status</th>
        <th>Date</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // Loop through the SQL query results and output each row as a table row
    while ($row = mysqli_fetch_assoc($result)) {
        // Extract the data from the current row
        $employee_emaitl = $row['employee_email'];
        $attendance = $row['attendance'];
        $created_at = $row['created_at'];
        $att_id = $row['att_id'];

        // Output the data as a table row
        echo '<tr>';
        echo '<td>' . $employee_emaitl . '</td>';
        echo '<td class="status ' . $attendance . '">' . $attendance . '</td>';
        echo '<td>' . $created_at . '</td>';
        echo '</tr>';
    }
    ?>
    </tbody>



</table>



<?php
require_once "include/footer.php";
?>